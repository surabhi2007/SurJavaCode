package emailValidator;

import java.util.Scanner;

public class EmailValidation {

	public static void main(String[] args) {
	
		 Scanner sc = new Scanner(System.in);
		 
		   String[] employeeEmails = {
		            "tiwarisurabhi@30.com",
		            "jyoti@16.com",
		            "ramtiwari@35.com",
		            "sujitatiwari@76.com",
		            "neha@168.com",
		            "abhitiwari@80.com",
		            "manutiwari@365.com",    
		        };
		       Scanner scanner = new Scanner(System.in);

		        //email_id search
		        System.out.print("Enter the email ID to search: ");
		        String emailToSearch = scanner.nextLine();

		        // Perform the search
		        boolean found = false;
		        for (String email : employeeEmails) {
		            if (email.equals(emailToSearch)) {
		               found = true;
		                break;
		            }
		        }

		        // Display the result
		        if (found) {
		            System.out.println( " was found in the list.");
		        } else {
		            System.out.println( " was not found in the list.");
		        }

		        // Close the scanner
		        scanner.close();
		    }
		}
			        
			    

