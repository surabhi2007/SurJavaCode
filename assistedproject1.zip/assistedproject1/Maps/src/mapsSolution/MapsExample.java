package mapsSolution;

import java.util.*;

public class MapsExample {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // HashMap
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Surabhi", 22);
        hashMap.put("Ram", 35);
        hashMap.put("Anjali", 19);

        // LinkedHashMap
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("six", 6);
        linkedHashMap.put("seven", 7);
        linkedHashMap.put("Three", 3);

        // TreeMap
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("july", 7);
        treeMap.put("august", 8);
        treeMap.put("Sep", 9);

        // Print HashMap
        System.out.println("HashMap:");
        for (String key : hashMap.keySet()) {
            System.out.println(key + " -> " + hashMap.get(key));
        }

        // Print LinkedHashMap
        System.out.println("\nLinkedHashMap:");
        for (String key : linkedHashMap.keySet()) {
            System.out.println(key + " -> " + linkedHashMap.get(key));
        }

        // Print TreeMap
        System.out.println("\nTreeMap:");
        for (String key : treeMap.keySet()) {
            System.out.println(key + " -> " + treeMap.get(key));
        }
    }

}
	


