package stringToBuffer;

public class StringToBuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  // Create a string
        String originalString = "Surabhi Tiwari!";
        
        // Convert the string to a StringBuffer
        StringBuffer stringBuffer = new StringBuffer(originalString);
        
        // Display the original string and the StringBuffer
        System.out.println("Original String: " + originalString);
        System.out.println("StringBuffer: " + stringBuffer.toString());
    }


	}


