package com.Lesson4.Constructor;
class EmpId
{
	int id;
	String name;
	void display() 
	{
	System.out.println(id+" "+name);
}
}

public class DefaultConstrustor {
	
	public static void main(String[] args) 
	{
	EmpId emp1=new EmpId();
	EmpId emp2=new EmpId();
	emp1.display();
	emp2.display();
	}
	
}

