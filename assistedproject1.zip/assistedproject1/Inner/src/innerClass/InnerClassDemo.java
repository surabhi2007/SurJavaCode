package innerClass;

class OuterClass {
    private int outerField = 188;

    class InnerClass {
        void displayOuterField() {
            System.out.println("Value of outerField: " + outerField);
        }
    }

    void outerMethod() {
        InnerClass inner = new InnerClass();
        inner.displayOuterField();
    }
}


public class InnerClassDemo {
	  public static void main(String[] args) {
	        OuterClass outer = new OuterClass();
	        outer.outerMethod();

	        // Creating an instance of InnerClass outside of OuterClass
	       
	        OuterClass.InnerClass inner = outer.new InnerClass();
	        inner.displayOuterField();
	    }
	}


