package typeCasting;

public class UserTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Implicit Type casting
		
	   int x = 5;
	    
	   double y = x;
	    System.out.println(y);
	    
	    // Explicit Type Casting
		double myDouble = 5.678;
		int myInt=(int)myDouble;
		
		System.out.println(myDouble);
		System.out.println(myInt);
		
		
		
				
	    
	}

	}


