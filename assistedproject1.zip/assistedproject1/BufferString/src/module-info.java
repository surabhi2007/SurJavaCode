/**
 * 
 */
/**
 * 
 */
module BufferString {
}