package regularExpression;
import java.util.regex.*;

public class UserRegularExpression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
String pattern = "[a-z,A-Z,0-9]+";
		
		String check = "I am Seeta  @@##$$%%@445566 Tiwari";
		
		Pattern p = Pattern.compile(pattern);
		Matcher c = p.matcher(check);
		
		while (c.find())
	      	System.out.println( check.substring( c.start(), c.end() ) );
	}

}
