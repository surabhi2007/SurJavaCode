/**
 * 
 */
/**
 * 
 */
module Regular {
}