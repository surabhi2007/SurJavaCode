package com.example.SpringSecurityMW;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityMwApplicationTests {

	@Test
	void contextLoads() {
	}

}
