package com.Sur.SpringSecurityMW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityMwApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityMwApplication.class, args);
	}

}
