/**
 * 
 */
/**
 * 
 */
module RightRotate {
}