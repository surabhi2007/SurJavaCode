package com.RightRotate;

public class UserRightRotate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   int[] arr = {1,5,7,8,9,4,11,23,56,89};
	        int steps = 5;

	        rightRotate(arr, steps);

	        System.out.println("Array after right rotation:");
	        for (int num : arr) {
	            System.out.print(num + " ");
	        }
	    }

	    public static void rightRotate(int[] arr, int steps) {
	        int n = arr.length;
	        steps = steps % n; // In case steps are greater than array length

	        // Create a temporary array to store the last 'steps' elements
	        int[] temp = new int[steps];
	        for (int i = 0; i < steps; i++) {
	            temp[i] = arr[n - steps + i];
	        }

	        // Shift the remaining elements to the right
	        for (int i = n - 1; i >= steps; i--) {
	            arr[i] = arr[i - steps];
	        }

	        // Copy the elements from the temporary array back to the beginning
	        for (int i = 0; i < steps; i++) {
	            arr[i] = temp[i];
	        }
	    }
	

	}


