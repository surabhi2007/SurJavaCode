package com.Singly;
class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    void deleteKey(int key) {
        Node current = head;
        Node prev = null;

        // If the key to be deleted is in the head node
        if (current != null && current.data == key) {
            head = current.next;
            return;
        }

        // Search for the key to be deleted, keeping track of the previous node
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If the key was not found in the list
        if (current == null) {
            System.out.println("Key not found in the list.");
            return;
        }

        // Unlink the node containing the key
        prev.next = current.next;
    }

    void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }


public class UserSinglyList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList list = new LinkedList();
        list.head = new Node(1);
        list.head.next = new Node(2);
        list.head.next.next = new Node(3);
        list.head.next.next.next = new Node(4);

        System.out.println("Original Linked List:");
        list.printList();

        int keyToDelete = 3;
        list.deleteKey(keyToDelete);

        System.out.println("Linked List after deleting key " + keyToDelete + ":");
        list.printList();
    }
}

	}


