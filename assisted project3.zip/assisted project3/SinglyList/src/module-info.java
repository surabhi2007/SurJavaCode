/**
 * 
 */
/**
 * 
 */
module SinglyList {
}