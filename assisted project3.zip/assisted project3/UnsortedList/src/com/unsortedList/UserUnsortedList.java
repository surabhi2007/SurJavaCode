package com.unsortedList;
import java.util.Arrays;


public class UserUnsortedList {
	public static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("List has less than 4 elements.");
            return -1;
        }

        // Sort the array in ascending order
        Arrays.sort(arr);

        // The fourth smallest element is at index 3 (0-based indexing)
        return arr[3];
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] unsortedList = {15, 6, 7, 3, 9, 5, 12, 1};
	        int fourthSmallest = findFourthSmallest(unsortedList);

	        if (fourthSmallest != -1) {
	            System.out.println("The fourth smallest element is: " + fourthSmallest);
		
	}

	}
}
