package com.Stack;
import java.util.Stack;

public class RemoveInsertStack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // Create a stack
        Stack<Integer> stack = new Stack<>();

        // Insert elements into the stack (push)
        stack.push(110);
        stack.push(220);
        stack.push(330);
        stack.push(400);

        System.out.println("Stack after pushing elements: " + stack);

        // Remove elements from the stack (pop)
        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);

        System.out.println("Stack after popping: " + stack);

        // Peek at the top element without removing it
        int topElement = stack.peek();
        System.out.println("Top element (without removing): " + topElement);

        // Check if the stack is empty
        boolean isEmpty = stack.isEmpty();
        System.out.println("Is the stack empty? " + isEmpty);
    }


	}


