/**
 * 
 */
/**
 * 
 */
module InsertRemoveStack {
}