package com.Queue;
import java.util.LinkedList;
import java.util.Queue;

public class UserRemoveInsert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Create a Queue using LinkedList
        Queue<String> queue = new LinkedList<>();

        // Enqueue elements (insert)
        queue.add("Element 2");
        queue.add("Element 3");
        queue.add("Element 4");

        System.out.println("Queue: " + queue);

        // Dequeue elements (remove)
        String removedElement = queue.poll(); // Removes and returns the head of the queue
        System.out.println("Removed Element: " + removedElement);

        System.out.println("Updated Queue: " + queue);
    }

	}

