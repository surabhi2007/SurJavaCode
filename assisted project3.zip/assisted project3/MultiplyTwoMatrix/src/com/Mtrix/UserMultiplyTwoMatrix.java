package com.Mtrix;

public class UserMultiplyTwoMatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] matrixA = {
	            {1, 22, 33},
	            {4, 5, 6},
	            {7, 8, 9}
	        };

	        int[][] matrixB = {
	            {10, 18, 17},
	            {6, 5, 14},
	            {3, 2, 11}
	        };

	        int rowsA = matrixA.length;
	        int colsA = matrixA[0].length;
	        int rowsB = matrixB.length;
	        int colsB = matrixB[0].length;

	        if (colsA != rowsB) {
	            System.out.println("Matrix multiplication is not possible.");
	            return;
	        }

	        int[][] result = new int[rowsA][colsB];

	        for (int i = 0; i < rowsA; i++) {
	            for (int j = 0; j < colsB; j++) {
	                int sum = 0;
	                for (int k = 0; k < colsA; k++) {
	                    sum += matrixA[i][k] * matrixB[k][j];
	                }
	                result[i][j] = sum;
	            }
	        }

	        // Display the result matrix
	        System.out.println("Resultant Matrix:");
	        for (int i = 0; i < rowsA; i++) {
	            for (int j = 0; j < colsB; j++) {
	                System.out.print(result[i][j] + " ");
	            }
	            System.out.println();
	        }
	    }
	

	}


