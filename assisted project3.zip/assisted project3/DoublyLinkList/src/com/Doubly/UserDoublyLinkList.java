package com.Doubly;
class Node {
    int data;
    Node next;
    Node prev;

    public Node(int data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}

class DoublyLinkedList {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
    }

    public void forwardTraversal() {
        Node current = head;
        System.out.print("Forward Traversal: ");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void backwardTraversal() {
        Node current = head;
        while (current != null && current.next != null) {
            current = current.next;
        }
        System.out.print("Backward Traversal: ");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }

public class UserDoublyLinkList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 DoublyLinkedList dll = new DoublyLinkedList();
	        dll.insert(1);
	        dll.insert(2);
	        dll.insert(3);
	        dll.insert(4);
	        dll.insert(5);

	        dll.forwardTraversal();
	        dll.backwardTraversal();
	    }
	}

	}


