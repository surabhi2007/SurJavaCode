package com.Sum;
import java.util.Scanner;

public class UserSumInRange {

	public static void main(String[] args) {
		// TODO Auto-generated method 
		Scanner scanner = new Scanner(System.in);

        // Input the number of elements
        System.out.print("Enter the number of elements (n): ");
        int n = scanner.nextInt();

        if (n <= 0) {
            System.out.println("Please enter a positive number of elements.");
            return;
        }

        int[] arr = new int[n];

        // Input the elements
        System.out.println("Enter the elements:");

        for (int i = 0; i < n; i++) {
            System.out.print("Element " + i + ": ");
            arr[i] = scanner.nextInt();
        }

        // Input the range [L, R]
        System.out.print("Enter the left index (L): ");
        int L = scanner.nextInt();

        System.out.print("Enter the right index (R): ");
        int R = scanner.nextInt();

        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range.");
            return;
        }

        // Calculate the sum of elements in the range [L, R]
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }

        System.out.println("Sum of elements in the range [" + L + ", " + R + "] is: " + sum);
    }


	}


