package com.practice.fitnessclubautomation.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.practice.fitnessclubautomation.model.Trainer;

@Repository
public interface TrainerRepository extends CrudRepository<Trainer, Long> {
}
