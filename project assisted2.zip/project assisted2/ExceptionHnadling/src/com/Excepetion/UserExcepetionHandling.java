package com.Excepetion;

public class UserExcepetionHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
            // Code that may throw an exception
            int result = divide(10, 0);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            // Catch and handle the specific exception
            System.err.println("Error: Division by zero");
        } finally {
            // This block will always execute, even if an exception occurs
            System.out.println("Execution completed.");
        }
    }

    public static int divide(int dividend, int divisor) {
        return dividend / divisor;
    }

	}


