package com.Crud;
import java.io.*;
import java.util.Scanner;

public class FileCRUD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Choose an operation:");
            System.out.println("1. Create File");
            System.out.println("2. Read File");
            System.out.println("3. Update File");
            System.out.println("4. Delete File");
            System.out.println("5. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createFile();
                    break;
                case 2:
                    readFile();
                    break;
                case 3:
                    updateFile();
                    break;
                case 4:
                    deleteFile();
                    break;
                case 5:
                    System.out.println("Exiting program.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please choose a valid option.");
                    break;
            }
        }
    }

    private static void createFile() {
        try {
            System.out.println("Enter the file name to create:");
            Scanner scanner = new Scanner(System.in);
            String fileName = scanner.nextLine();

            File file = new File(fileName);

            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    private static void readFile() {
        try {
            System.out.println("Enter the file name to read:");
            Scanner scanner = new Scanner(System.in);
            String fileName = scanner.nextLine();

            File file = new File(fileName);

            Scanner fileReader = new Scanner(file);

            while (fileReader.hasNextLine()) {
                String data = fileReader.nextLine();
                System.out.println(data);
            }
            fileReader.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    private static void updateFile() {
        try {
            System.out.println("Enter the file name to update:");
            Scanner scanner = new Scanner(System.in);
            String fileName = scanner.nextLine();

            System.out.println("Enter the content to append:");
            String content = scanner.nextLine();

            FileWriter fileWriter = new FileWriter(fileName, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(content);
            bufferedWriter.newLine();
            bufferedWriter.close();

            System.out.println("Content appended to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    private static void deleteFile() {
        try {
            System.out.println("Enter the file name to delete:");
            Scanner scanner = new Scanner(System.in);
            String fileName = scanner.nextLine();

            File file = new File(fileName);

            if (file.delete()) {
                System.out.println("File deleted: " + file.getName());
            } else {
                System.out.println("File not found.");
            }
        } catch (Exception e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }


	}


