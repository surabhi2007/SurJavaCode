/**
 * 
 */
/**
 * 
 */
module Synchronized {
}