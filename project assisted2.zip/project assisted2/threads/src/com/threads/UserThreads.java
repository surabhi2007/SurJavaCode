package com.threads;

public class UserThreads {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  // Create and start a thread using a lambda expression
        Thread thread = new Thread(() -> {
            for (int i = 1; i <= 5; i++) {
                System.out.println("Thread using lambda: " + i);
            }
        });
        thread.start();
    }


	}


