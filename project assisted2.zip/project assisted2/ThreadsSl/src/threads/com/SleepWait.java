package threads.com;

public class SleepWait {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread sleepingThread = new Thread(new SleepingThread());
        Thread waitingThread = new Thread(new WaitingThread());

        sleepingThread.start();
        waitingThread.start();
    }
}

class SleepingThread implements Runnable {
    @Override
    public void run() {
        System.out.println("Sleeping Thread: Started");
        try {
            Thread.sleep(3000); // Sleep for 3 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Sleeping Thread: Finished");
    }
}

class WaitingThread implements Runnable {
    @Override
    public void run() {
        System.out.println("Waiting Thread: Started");
        synchronized (this) {
            try {
                wait(5000); // Wait for 5 seconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Waiting Thread: Finished");
    }


	}


