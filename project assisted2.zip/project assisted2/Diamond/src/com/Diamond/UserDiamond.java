package com.Diamond;
interface A {
    default void display() {
        System.out.println("A");
    }
}

interface B extends A {
    default void display() {
        System.out.println("B");
    }
}

interface C extends A {
    default void display() {
        System.out.println("C");
    }
}

class D implements B, C {
    // To resolve the diamond problem, you can provide your implementation of the display method.
    @Override
    public void display() {
        // You can choose to call the specific interface's display method using super.
        B.super.display(); // Calls the display method from interface B
        C.super.display(); // Calls the display method from interface C
    }
}

public class UserDiamond {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 D obj = new D();
	        obj.display(); // Output will be "B" followed by "C"
	    }
	

	}


