package com.Try;

public class UserTry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  try {
	            int[] numbers = {1, 2, 3};
	            System.out.println("Accessing element at index 3: " + numbers[3]);
	        } catch (ArrayIndexOutOfBoundsException e) {
	            System.out.println("An exception occurred: " + e.getMessage());
	        }
	    }
	

	}


