/**
 * 
 */
/**
 * 
 */
module exponentialAlgo {
}