package exponentialAlgo;

public class UserExponentialAlgo {

	 public static int exponentialSearch(int[] arr, int target) {
	        int n = arr.length;
	        
	        if (arr[0] == target) {
	            return 0; // Element found at index 0
	        }
	        
	        // Find the range for binary search
	        int i = 1;
	        while (i < n && arr[i] <= target) {
	            i *= 2;
	        }
	        
	        // Perform binary search in the found range
	        return binarySearch(arr, target, i / 2, Math.min(i, n - 1));
	    }

	    private static int binarySearch(int[] arr, int target, int low, int high) {
	        if (low <= high) {
	            int mid = low + (high - low) / 2;
	            
	            if (arr[mid] == target) {
	                return mid; // Element found
	            } else if (arr[mid] < target) {
	                return binarySearch(arr, target, mid + 1, high); // Search in the right half
	            } else {
	                return binarySearch(arr, target, low, mid - 1); // Search in the left half
	            }
	        }
	        
	        return -1; // Element not found
	    }
	public static void main(String[] args) {
		 int[] arr = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
	        int target = 12;
	        int result = exponentialSearch(arr, target);
	        
	        if (result != -1) {
	            System.out.println("Element found at index " + result);
	        } else {
	            System.out.println("Element not found in the array");
	        }
	    }
	

	}


