package com.Linear;


public class UserLinearSearch {
	public class LinearSearch {
	    public static int linearSearch(int[] arr, int target) {
	        for (int i = 0; i < arr.length; i++) {
	            if (arr[i] == target) {
	                return i; // Return the index where the target element was found
	            }
	        }
	        return -1; // Return -1 if the target element was not found in the array
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {100, 205, 400, 107, 80, 102, 271};
        int target = 80;

        int result = linearSearch(arr, target);

        if (result != -1) {
            System.out.println("Element " + target + " found at index " + result);
        } else {
            System.out.println("Element " + target + " not found in the array.");
        }
    }
}

	}


