# RailwayCrossingStatus
This is an application that can communicate the status of a railway crossing to the public in advance.
